# Embedded file name: /mnt/33/new/ee/mkiviDebV3.0/pytopyc/ivic-core_2.0+r3310_all/usr/share/pyshared/ivic/__init__.py
__version__ = '2.0+r8537+20110511'
