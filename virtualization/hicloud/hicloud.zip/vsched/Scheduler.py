from ParseNet import *
from Utils import *
from ImportedModel import *
import Logging
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine

logger = Logging.get_logger('hicloud.vsched.Scheduler')

def randomMac():
    Maclist = []
    for i in range(1,7):
	RANDSTR = "".join(random.sample("0123456789abcdef",2))
	Maclist.append(RANDSTR)
    randMac = ":".join(Maclist)
    return randMac

def generateMac(session):
    logger.info("generateMac is running")
    MACs = session.query(Macs).all()
    mac_address = ""
    for MAC in MACs:
	if MAC.status == 0:
	    mac_address = MAC.address
            MAC.status = 1
            session.commit()
            break
    if mac_address=="":
	mac_address = randomMac()
    logger.info("get a mac address: %s"%(mac_address))
    return mac_address

def generateVMCid(session):
    logger.info("generateVMCid is running")
    vmcs = session.query(VirtualMachineContainer).all()
    vmcid = -1
    for vmc in vmcs:
        if vmc.vmi_num < vmc.max_vmi_num:
            vmcid = vmc.id
            vmc.vmi_num = vmc.vmi_num + 1
            session.commit()
            break
    logger.info("get the vmcid: %s"%vmcid)
    return vmcid

def completeXML(Settings, Uuid, Hostname, CpuCnt, Mem, NicCnt, DiskSize, OsType, OsVersion, SoftwareType, IsoPath, Vlan, MAC, DNS):
    logger.info("completeXML is running")
    logger.info("Settings: %s"%Settings)
    logger.info("Uuid: %s, Hostname: %s, CpuCnt: %s, Mem: %s, NicCnt: %s, DiskSize: %s, OsType: %s, OsVersion: %s, SoftwareType: %s, IsoPath: %s, Vlan: %s, MAC: %s, DNS: %s"%(str(Uuid), str(Hostname), str(CpuCnt), str(Mem), str(NicCnt), str(DiskSize), str(OsType), str(OsVersion), str(SoftwareType), str(IsoPath), str(Vlan), str(MAC), str(DNS)))
    xmldoc = minidom.parseString(Settings.encode("utf-8"))
    xmldoc.getElementsByTagName('Uuid')[0].firstChild.replaceWholeText(Uuid)
    xmldoc.getElementsByTagName('Hostname')[0].firstChild.replaceWholeText(Hostname)
    xmldoc.getElementsByTagName('CpuCnt')[0].firstChild.replaceWholeText(CpuCnt)
    xmldoc.getElementsByTagName('Mem')[0].firstChild.replaceWholeText(Mem)
    xmldoc.getElementsByTagName('NicCnt')[0].firstChild.replaceWholeText(NicCnt)
    xmldoc.getElementsByTagName('DiskSize')[0].firstChild.replaceWholeText(DiskSize)
    xmldoc.getElementsByTagName('OsType')[0].firstChild.replaceWholeText(OsType)
    xmldoc.getElementsByTagName('OsVersion')[0].firstChild.replaceWholeText(OsVersion)
    xmldoc.getElementsByTagName('SoftwareType')[0].firstChild.replaceWholeText(SoftwareType)
    xmldoc.getElementsByTagName('Vlan')[0].firstChild.replaceWholeText(Vlan)
    xmldoc.getElementsByTagName('MAC')[0].firstChild.replaceWholeText(MAC)
    xmldoc.getElementsByTagName('DNS')[0].firstChild.replaceWholeText(DNS)
    re_settings = xmldoc.toxml()
    logger.info("Completed Settings: %s"%Settings)
    return re_settings

#add VMI class instances into the database 
def addVMIs(os_name, os_version, software_type, session):
    logger.info("add VMIs is running. OsType: %s, OsVersion: %s, SoftwareType: %s"%(os_name, os_version, software_type))
    Uuid = GenUUID()
    if software_type.strip() == "PLC":
        Hostname = os_name.strip()+"-"+os_version.strip()+'-Server-'+software_type.strip()+'-'+Uuid.strip()
    else:
        Hostname = os_name.strip()+"-"+os_version.strip()+'-Desktop-'+software_type.strip()+'-'+Uuid.strip()
    CpuCnt = '1'
    Mem = '256'
    NicCnt = '1'
    DiskSize = '1'
    VstoreIP = '127.0.0.1'
    VstorePath = '/tmp/adtp-master/hicloud/vstore'
    StoreType = 'local'
    OsType = os_name
    OsVersion = os_version
    SoftwareType = software_type
    IsoPath = '/vmc160/'
    Vlan = '0'
    Address = '0.0.0.0'
    Network = '255.255.255.0'
    GateWay = '172.20.0.1'
    MAC = generateMac(session)
    DNS = '1.2.4.8'
    Settings = '<vNode><Uuid>107b03a6-5d99-11e6-9477-000c29bf9897</Uuid><Type> </Type><Hostname>Ubuntu-Server-PLC</Hostname><Desc> </Desc><CpuCnt>1</CpuCnt><Mem>256</Mem><NicCnt>1</NicCnt><DiskSize>1</DiskSize><VstoreIp>127.0.0.1</VstoreIp><VstorePath>/tmp/adtp-master/hicloud/vstore</VstorePath><StorageType>local</StorageType><OsType>Ubuntu</OsType><OsVersion>16</OsVersion><SoftwareType>PLC</SoftwareType><vTemplateRef> </vTemplateRef><IsoPath>/vmc160/ubuntu-16.04.4-server-amd64.iso</IsoPath><NIC id=\'1\'><Vlan>0</Vlan><Address>0.0.0.0</Address><Netmask>255.255.255.0</Netmask><Gateway>172.20.0.1</Gateway><MAC>52:54:00:dc:f4:d8</MAC><DNS>1.2.4.8</DNS></NIC><Password> </Password></vNode>'
    Settings = completeXML(Settings, Uuid, Hostname, CpuCnt, Mem, NicCnt, DiskSize, OsType, OsVersion, SoftwareType, IsoPath, Vlan, MAC, DNS)
    vmc_id = generateVMCid(session)
    vstore_ip = session.query(VirtualMachineContainer).filter(VirtualMachineContainer.id == vmc_id).all()[0].address
    newVMI = VirtualMachineInstance(uuid = Uuid, hostname = Hostname, virtual_machine_container_id = vmc_id, cpu_cnt = CpuCnt, mem_total = Mem, nic_cnt = NicCnt, disk_total = DiskSize, ip = vstore_ip, store_type = StoreType, oper_system_type = OsType, oper_system_version = OsVersion, software_type = SoftwareType, settings = Settings)
    session.add(newVMI)
    session.commit()
#add Switch class instances into the database
def addSwitchs():
    return 0 

#parse the topology net and add its devices into the database
def addNet(xml):
	device_names = ParseNet(xml)
        try:
	    engine = create_engine('mysql://debian-sys-maint:jAYKfnrf0JjY4Zz8@localhost/tryHicloud_db')
            DBsession = sessionmaker(bind = engine)
            session = DBsession()
            MACs = session.query(Macs).all()
            for MAC in MACs:
                MAC.status = 0
                session.commit()
            VMCs = session.query(VirtualMachineContainer).all()
            for VMC in VMCs:
                VMC.vmi_num = 0
                session.commit()

            logger.info("create the session to mysql tryHicloud_db")
	except Exception as e:
	    logger.info("fail to create the session to mysql tryHicloud_db: %s"%str(e))
	for i in range(len(device_names)):
	    if i%2!=0:    #vmi 
                logger.info("This is a vmi of type %s"%str(device_names[i]))
		addVMIs('ubuntu', '16', device_names[i], session)
	    else:         #switch
                logger.info("This is a switch") 
	session.close()
 
xml = "<topology type='network'>\n\
<name>tryNet</name>\n\
<nodes>\n\
<node name='HMI'></node>\n\
<node name='Switch'></node>\n\
<node name='Unity'></node>\n\
<node name='AD'></node>\n\
<node name='PLC'></node>\n\
</nodes>\n\
<links>\n\
<link endpoint1='Switch' endpoint2='HMI'></link>\n\
<link endpoint1='Switch' endpoint2='Unity'></link>\n\
<link endpoint1='Switch' endpoint2='AD'></link>\n\
<link endpoint1='Switch' endpoint2='PLC'></link>\n\
</links>\n\
</topology>"
addNet(xml)
