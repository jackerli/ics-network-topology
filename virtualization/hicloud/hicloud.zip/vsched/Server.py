# -*- coding: utf-8 -*-

import time

import SOAPpy
import commands

from hicloud.vsched.Impl import Impl
from hicloud.vsched.Interface import Interface
from hicloud.vsched.Model import *

logger = Logging.get_logger(__name__)


def zeroReturnWrapper(fun):
    def __wrapper(*args, **kwargs):
        try:
            return fun(*args, **kwargs)
        except Exception as e:
            logger.exception(e)
            return 1

    return __wrapper


def nullReturnWrapper(fun):
    def __wrapper(*args, **kwargs):
        try:
            return fun(*args, **kwargs)
        except Exception as e:
            logger.exception(e)
            return None

    return __wrapper


class ServerClass(Interface):
    def __init__(self, config):
        # save config
        self.config = config

        # dump config string
        for k, v in self.config.items():
            if type(v) == str:
                logger.debug('config var: %s = %s', k, v)

        # init session and impl
        session = get_session(self.config['connect_string'])
        self.s = session
        self.impl = Impl(session)

    @zeroReturnWrapper
    def importTemplate(self, xml):
        '''import XML into Portal's database
    Return Value
        Integer 0 - for successfully import
        Integer ErrorIndex - for user to get import error'''
        self.impl.importTemplate(xml)
        return 0

    @nullReturnWrapper
    def listTemplate(self):
        '''list template
    Return Value:
        String - a list containing each template's UUID, Type, Name'''
        return self.impl.listTemplate()

    @nullReturnWrapper
    def listTemplateByType(self, typ):
        '''list template by `type`
    Argument `type` - vLab, vCluster, vTemplate
    Return Value:
        String - a list containing each template's UUID, Type, Name
        NULL - for invalid `type`'''
        return self.impl.listTemplateByType(typ)

    @nullReturnWrapper
    def listVmTemp(self):
        return self.impl.listVmTemp()

    @nullReturnWrapper
    def vmi_create_time(self, uuid):
        return self.impl.getVmCreateTime(uuid)

    @nullReturnWrapper
    def vmi_recentstart_time(self, uuid):
        return self.impl.getVmRecentStartTime(uuid)

    @nullReturnWrapper
    def showTemplate(self, uuid):
        '''show template info by UUID
    Return Value:
        String - XML information of a template
        NULL - for invalid `key`'''
        return self.impl.showTemplate(uuid)

    @nullReturnWrapper
    def showInstance(self, uuid):
        '''show instance info by UUID
    Return Value:
        String - XML information of a instance
        NULL - fro invalid uuid'''
        return self.impl.showInstance(uuid)

    @nullReturnWrapper
    def showTemplateByKey(self, key):
        return self.impl.showTemplateByKey(key)

    @zeroReturnWrapper
    def removeTemplate(self, uuid):
        self.impl.removeTemplate(uuid)
        return 0

    @zeroReturnWrapper
    def removeTemplateByKey(self, key):
        self.impl.removeTemplateByKey(key)
        return 0

    @nullReturnWrapper
    def listInstance(self):
        return self.impl.listInstance()

    @nullReturnWrapper
    def listInstanceByType(self, typ):
        return self.impl.listInstanceByType(xml, typ)

    def removeInstance(self, uuid):
        self.impl.removeInstance(uuid)
        return 0

    def removeInstanceByKey(self, key):
        self.impl.removeInstanceByKey(key)
        return 0

    def __wait_job(self, id):
        while True:
            job = self.s.query(Job).get(id)
            if job.status == 'finished':
                return '1'
            elif job.status == 'failed':
                return '0'
            else:
                self.s.close()
                time.sleep(1)

    # 根据模板创建虚机
    @zeroReturnWrapper
    def deployV(self, template_uuid, param, ip_pool_id):
        logger.info('***** Server.py deployV is running *****')
        # 装换数据格式
        param2dict = {}
        for item in param.item:
            logger.info('%s ** %s' % (item.key, item.value))
            param2dict[item.key] = item.value

        job_uuid = self.impl.deployV(template_uuid, param2dict, ip_pool_id)
        return job_uuid

    # 根据iso创建虚机
    @zeroReturnWrapper
    def createV(self, vmi_uuid, param):
        logger.info('***** Server.py createV is running *****')
        # 装换数据格式
        param2dict = {}
        for item in param.item:
            logger.info('%s ** %s' % (item.key, item.value))
            param2dict[item.key] = item.value

        job_uuid = self.impl.createV(vmi_uuid, param2dict)
        return job_uuid

    @zeroReturnWrapper
    def redeployV(self, uuid):
        logger.info('***** Server.py redeployV is running *****')
        job_uuid = self.impl.redeployV(uuid)
        return job_uuid

    # 开启虚拟机
    @zeroReturnWrapper
    def startV(self, vmi_uuid):
        logger.info('***** Server.py startV is running *****')
        job_uuid = self.impl.startV(vmi_uuid)
        return job_uuid

    # 停止虚拟机
    @zeroReturnWrapper
    def stopV(self, vmi_uuid):
        logger.info('***** Server.py stopV is running *****')
        job_uuid = self.impl.stopV(vmi_uuid)
        return job_uuid

    # 删除虚拟机
    @zeroReturnWrapper
    def undeployV(self, vmi_uuid):
        logger.info('***** Server.py undeployV is running *****')
        job_uuid = self.impl.undeployV(vmi_uuid)
        return job_uuid

    # 重启虚拟机
    @zeroReturnWrapper
    def restartV(self, vmi_uuid):
        logger.info('***** Server.py restartV is running *****')
        job_uuid = self.impl.restartV(vmi_uuid)
        return job_uuid

    # 暂停虚拟机
    @zeroReturnWrapper
    def pauseV(self, vmi_uuid):
        logger.info('***** Server.py pauseV is running *****')
        job_uuid = self.impl.pauseV(vmi_uuid)
        return job_uuid

    # 唤醒虚拟机
    @zeroReturnWrapper
    def resumeV(self, vmi_uuid):
        logger.info('***** Server.py resumeV is running *****')
        job_uuid = self.impl.resumeV(vmi_uuid)
        return job_uuid

    # 修改虚拟机配置
    @zeroReturnWrapper
    def reconfigV(self, vmi_uuid, config_xml):
        logger.info('***** Server.py reconfigV is running *****')
        # xml="<config><CpuCnt>2</CpuCnt><Mem>1049600</Mem><NicCnt>2</NicCnt><DiskSize>1g</DiskSize></config>"
        logger.info('id: %s, xml: %s' % (vmi_uuid, config_xml))
        job_uuid = self.impl.reconfig(vmi_uuid, config_xml.strip())
        return job_uuid

    # 重命名虚拟机
    @zeroReturnWrapper
    def renameV(self, vmi_uuid, name):
        logger.info('***** Server.py renameV is running *****')
        result = self.impl.rename(vmi_uuid, name)
        return str(result)

    # 开启虚拟机
    @zeroReturnWrapper
    def startVmiByKey(self, key):
        logger.info('***** Server.py startVmiByKey is running *****')
        job_uuid = self.impl.startV_ByKey(key)
        return job_uuid

    # 关闭虚拟机
    @zeroReturnWrapper
    def stopVmiByKey(self, key):
        logger.info('***** Server.py stopVmiByKey is running *****')
        job_uuid = self.impl.stopV_ByKey(key)
        return job_uuid

    # 删除虚拟机
    @zeroReturnWrapper
    def undeployVmiByKey(self, key):
        logger.info('***** Server.py undeployVmiByKey is running *****')
        job_uuid = self.impl.undeployV_ByKey(key)
        return job_uuid

    # 创建模板
    def createTempByParam(self, temp_name, storage_uuid, vmi_uuid):
        logger.info('***** Server.py createTempByParam is running *****')
        try:
            job_uuid = self.impl.createTempByParam(temp_name.strip(), storage_uuid.strip(), vmi_uuid.strip())
            return job_uuid
        except Exception as e:
            logger.error(e.message)
            return None

    # 克隆虚拟机
    def cloneVm(self, clone_vm_name, vmi_uuid):
        logger.info('***** Server.py cloneVm is running *****')
        try:
            job_uuid = self.impl.cloneVm(clone_vm_name.strip(), vmi_uuid.strip())
            if job_uuid is None:
                logger.error('cloneVm is error')
                return None
            else:
                return job_uuid
        except Exception as e:
            logger.error(e.message)
            return None

    # 迁移虚拟机
    def migrateVm(self, vmi_uuid, remote_vmc_uuid):
        logger.info('***** servie.py migrateVm is running *****')
        try:
            job_uuid = self.impl.migrateVm(vmi_uuid, remote_vmc_uuid)
            if job_uuid is None:
                return None
            else:
                return job_uuid
        except Exception as e:
            logger.error('migrate is error: %s' % e.message)
            return None

    # 创建快照
    def snapshotVm(self, vmi_uuid, snapshot_name, snapshot_description):
        logger.info('***** servie.py snapshotVm is running *****')
        try:
            job_uuid = self.impl.createSnapshotVm(vmi_uuid, snapshot_name, snapshot_description)
            if job_uuid is None:
                return None
            else:
                return job_uuid
        except Exception as e:
            logger.error('create snapshot is error: %s' % e.message)
            return None

    # 恢复快照
    def rollbackVm(self, vmi_uuid, snapshot_uuid):
        logger.info('***** servie.py rollbackVm is running *****')
        try:
            job_uuid = self.impl.rollbackVmById(vmi_uuid, snapshot_uuid)
            if job_uuid is None:
                return None
            else:
                return job_uuid
        except Exception as e:
            logger.error('rollback is error: %s' % e.message)
            return None

    # 重命名快照
    def renameSnapshot(self, old_snapshot_uuid, new_snapshot_name, description):
        logger.info('***** servie.py renameSnapshot is running *****')
        try:
            result = self.impl.renameSnapshot(old_snapshot_uuid, new_snapshot_name, description)
            if result is None:
                return None
            else:
                return result
        except Exception as e:
            logger.error('rename snapshot is error: %s' % e.message)
            return None

    # 删除指定名称的快照
    def removeSnapshotById(self, vmi_uuid, snapshot_uuid, is_remove_child):
        logger.info('***** servie.py removeSnapshotById is running *****')
        try:
            job_uuid = self.impl.removeSnapshotById(vmi_uuid, snapshot_uuid, is_remove_child)
            if job_uuid is None:
                return None
            else:
                return job_uuid
        except Exception as e:
            logger.error('remove snapshot is error: %s' % e.message)
            return None

    # 删除一个虚拟机的所有快照列表
    def removeAllSnapshot(self, vmi_uuid):
        logger.info('***** servie.py removeAllSnapshot is running *****')
        try:
            job_uuid = self.impl.removeAllSnapshot(vmi_uuid)
            if job_uuid is None:
                return None
            else:
                return job_uuid
        except Exception as e:
            logger.error('remove snapshot is error: %s' % e.message)
            return None

    # 获取一个虚拟机的所有快照列表
    def getSnapshotsByVmiUuid(self, vmi_uuid):
        logger.info('***** Server.py getSnapshotsByVmiUuid is running *****')
        try:
            snapshots = self.impl.getSnapshotsByVmiUuid(vmi_uuid)
            if snapshots is None or len(snapshots) == 0:
                return None

            wrapped_snapshots = []
            for snapshot in snapshots:
                snapshot2dict = {}
                for key in snapshot.__dict__:
                    snapshot2dict[key] = getattr(snapshot, key)
                snapshot2dict["_typename"] = snapshot.__class__.__name__
                wrappedObj = SOAPpy.Types.structType(snapshot2dict)
                wrapped_snapshots.append(wrappedObj)
            return SOAPpy.Types.arrayType(wrapped_snapshots)
        except Exception as e:
            logger.error('getSnapshots is error: %s' % e.message)
            return None

    # 获取所有物理主机
    def getAllHost(self):
        logger.info('***** Server.py getAllHost is running *****')
        try:
            vmcs = self.impl.getAllHost()
            if vmcs is None or len(vmcs) == 0:
                return None

            Hosts = []
            for vmc in vmcs:
                vmc2dict = {}
                for key in vmc.__dict__:
                    vmc2dict[key] = getattr(vmc, key)
                vmc2dict["_typename"] = vmc.__class__.__name__
                wrappedObj = SOAPpy.Types.structType(vmc2dict)
                Hosts.append(wrappedObj)
            return SOAPpy.Types.arrayType(Hosts)
        except Exception as e:
            logger.error('getAllHost is error: %s' % e.message)
            return None

    # 获取指定id的物理主机
    def getHostByUuid(self, vmc_uuid):
        logger.info('***** Server.py getHostByUuid is running *****')
        vmc = self.impl.getHostByUuid(vmc_uuid)
        if vmc is None:
            return None

        host = {}
        try:
            for key in vmc.__dict__:
                host[key] = getattr(vmc, key)
            host["_typename"] = vmc.__class__.__name__
            return SOAPpy.Types.structType(host)
        except Exception as e:
            logger.error('getHostByUuid is error: %s' % e.message)
            return None

    # 获取指定名称的物理主机
    def getHostByName(self, hostname):
        logger.info('***** Server.py getHostByName is running *****')
        vmc = self.impl.getHostByName(hostname)
        if vmc is None:
            return None

        host = {}
        try:
            for key in vmc.__dict__:
                host[key] = getattr(vmc, key)
            host["_typename"] = vmc.__class__.__name__
            return SOAPpy.Types.structType(host)
        except Exception as e:
            logger.error('getHostByName is error: %s' % e.message)
            return None

    # 获取指定集群id下的物理主机
    def getHostsByClusterUuid(self, cluster_uuid):
        logger.info('***** Server.py getHostsByClusterUuid is running *****')
        try:
            hosts = self.impl.getHostsByClusterUuid(cluster_uuid)
            if hosts is None or len(hosts) == 0:
                return None

            Hosts = []
            for host in hosts:
                host2dict = {}
                for key in host.__dict__:
                    host2dict[key] = getattr(host, key)
                host2dict["_typename"] = host.__class__.__name__
                wrappedObj = SOAPpy.Types.structType(host2dict)
                Hosts.append(wrappedObj)
            return SOAPpy.Types.arrayType(Hosts)
        except Exception as e:
            logger.error('getHostsByClusterUuid is error: %s' % e.message)
            return None

    # 获取指定集群名称下的物理主机
    def getHostsByClusterName(self, clustername):
        logger.info('***** Server.py getHostsByClusterName is running *****')
        try:
            hosts = self.impl.getHostsByClusterName(clustername)
            if hosts is None or len(hosts) == 0:
                return None

            Hosts = []
            for host in hosts:
                host2dict = {}
                for key in host.__dict__:
                    host2dict[key] = getattr(host, key)
                host2dict["_typename"] = host.__class__.__name__
                wrappedObj = SOAPpy.Types.structType(host2dict)
                Hosts.append(wrappedObj)
            return SOAPpy.Types.arrayType(Hosts)
        except Exception as e:
            logger.error('getHostsByClusterName is error: %s' % e.message)
            return None

    # 获取指定数据中心下的集群
    def getClustersByDatacenterUuid(self, datacenter_uuid):
        logger.info('***** Server.py getClustersByDatacenterUuid is running *****')
        try:
            clusters = self.impl.getClustersByDatacenterUuid(datacenter_uuid)
            if clusters is None or len(clusters) == 0:
                return None

            Clusters = []
            for cluster in clusters:
                cluster2dict = {}
                for key in cluster.__dict__:
                    cluster2dict[key] = getattr(cluster, key)
                cluster2dict["_typename"] = cluster.__class__.__name__
                wrappedObj = SOAPpy.Types.structType(cluster2dict)
                Clusters.append(wrappedObj)
            return SOAPpy.Types.arrayType(Clusters)
        except Exception as e:
            logger.error('getClustersByDatacenterUuid is error: %s' % e.message)

    # 获取指定id的数据中心
    def getHostsByDatacenterUuid(self, datacenter_uuid):
        logger.info('***** Server.py getHostsByDatacenterUuid is running *****')
        try:
            hosts = self.impl.getHostsByDatacenterUuid(datacenter_uuid)
            if hosts is None or len(hosts) == 0:
                return None

            Hosts = []
            for host in hosts:
                host2dict = {}
                for key in host.__dict__:
                    host2dict[key] = getattr(host, key)
                host2dict["_typename"] = host.__class__.__name__
                wrappedObj = SOAPpy.Types.structType(host2dict)
                Hosts.append(wrappedObj)
            return SOAPpy.Types.arrayType(Hosts)
        except Exception as e:
            logger.error('getHostsByDatacenterId is error: %s' % e.message)
            return None

    # 获取数据中心列表
    def getDatacenters(self):
        logger.info('***** Server.py getDatacenters is running *****')
        try:
            datacenters = self.impl.getDatacenters()
            if datacenters is None or len(datacenters) == 0:
                return None

            Datas = []
            for datacenter in datacenters:
                datacenter2dict = {}
                for key in datacenter.__dict__:
                    datacenter2dict[key] = getattr(datacenter, key)
                datacenter2dict["_typename"] = datacenter.__class__.__name__
                wrappedObj = SOAPpy.Types.structType(datacenter2dict)
                Datas.append(wrappedObj)
            Datacenter = SOAPpy.Types.arrayType(Datas)
            return Datacenter
        except Exception as e:
            logger.error('getDatacenters is error: %s' % e.message)
            return None

    # 获取所有模板列表
    def getAllTemplates(self):
        logger.info('***** Server.py getAllTemplates is running *****')
        try:
            templates = self.impl.getAllTemplates()
            if templates is None or len(templates) == 0:
                return None

            Temps = []
            for template in templates:
                template2dict = {}
                for key in template.__dict__:
                    template2dict[key] = getattr(template, key)
                template2dict["_typename"] = template.__class__.__name__
                wrappedObj = SOAPpy.Types.structType(template2dict)
                Temps.append(wrappedObj)
            return SOAPpy.Types.arrayType(Temps)
        except Exception as e:
            logger.error('getAllTemplates is error: %s' % e.message)
            return None

    # 获取所有虚拟机列表
    def getAllVmis(self):
        logger.info('***** Server.py getAllVmi is running *****')
        try:
            vmis = self.impl.getAllVmis()
            if vmis is None or len(vmis) == 0:
                return None

            warpped_vmis = []
            for vmi in vmis:
                vmi2dict = {}
                for key in vmi.__dict__:
                    vmi2dict[key] = getattr(vmi, key)
                vmi2dict["_typename"] = vmi.__class__.__name__
                warpped_vmis.append(SOAPpy.Types.structType(vmi2dict))
            return SOAPpy.Types.arrayType(warpped_vmis)
        except Exception as e:
            logger.error(e.message)
            return None

    # 获取指定id的虚拟机
    def getVmiByUuid(self, vmi_uuid):
        logger.info('***** Server.py getVmiByUuid is running *****')
        vmi = self.impl.getVHostByUuid(vmi_uuid)
        if vmi is None:
            return None

        vhost = {}
        try:
            for key in vmi.__dict__:
                vhost[key] = getattr(vmi, key)
            vhost["_typename"] = vmi.__class__.__name__
            wrappedObj = SOAPpy.Types.structType(vhost)
            return wrappedObj
        except Exception as e:
            logger.error(e.message)
            return None

    # 获取指定名称的虚拟机
    def getVmiByName(self, hostname):
        logger.info('***** Server.py getHostByName is running *****')
        vmi = self.impl.getVHostByName(hostname.strip())
        if vmi is None or len(vmi) == 0:
            return None

        vhost = {}
        try:
            for key in vmi[0].__dict__:
                vhost[key] = getattr(vmi[0], key)
            vhost["_typename"] = vmi[0].__class__.__name__
            wrappedObj = SOAPpy.Types.structType(vhost)
            return wrappedObj
        except Exception as e:
            logger.error(e.message)
            return None

    # 获取一个物理主机上的所有虚拟机列表
    def getVmisByHostUuid(self, host_uuid):
        logger.info('***** Server.py getVmisByHostUuid is running *****')
        try:
            vmis = self.impl.getVmisByHostUuid(host_uuid)
            if vmis is None or len(vmis) == 0:
                return None

            vHosts = []
            for i in range(len(vmis)):
                vmi = {}
                for key in vmis[i].__dict__:
                    vmi[key] = getattr(vmis[i], key)
                vmi["_typename"] = vmis[i].__class__.__name__
                wrappedObj = SOAPpy.Types.structType(vmi)
                vHosts.append(wrappedObj)
            return SOAPpy.Types.arrayType(vHosts)
        except Exception as e:
            logger.error(e.message)
            return None

    # 获取任务状态
    def getJobState(self, job_uuid):
        logger.info('***** Server.py getTaskState is running *****')
        # 任务状态：0错误,1排队,2进行中,3成功
        try:
            job = self.impl.getJobById(job_uuid)
            if job is None:
                return None

            state = 0
            if job.status == 'pending':
                state = 1
            elif job.status == 'scheduling':
                state = 2
            elif job.status == 'finished':
                state = 3
            elif job.status == 'failed':
                state = 0
            return str(state)
        except Exception as e:
            logger.error(e.message)
            return None

    # 删除指定模板
    def removeTemplateByVmiUuid(self, temp_uuid):
        logger.info('***** Server.py removeTemplateByVmiUuid is running *****')
        try:
            result = self.impl.removeTemplateByVmiUuid(temp_uuid)
            return str(result)
        except Exception as e:
            logger.error(e.message)
            return None

    # 获取所有警告列表
    def getAllAlarms(self):
        logger.info('***** Server.py getAllAlarms is running *****')
        try:
            alarms = self.impl.getAllAlarms()
            if alarms is None or len(alarms) == 0:
                return None

            warpped_alarms = []
            for alarm in alarms:
                alarm2dict = {}
                for key in alarm.__dict__:
                    alarm2dict[key] = getattr(alarm, key)
                alarm2dict["_typename"] = alarm.__class__.__name__
                warpped_alarms.append(SOAPpy.Types.structType(alarm2dict))
            return SOAPpy.Types.arrayType(warpped_alarms)
        except Exception as e:
            logger.error(e.message)
            return None

    # 根据警告实体id获取警告列表
    def getAlarmsByObjId(self, vmc_uuid):
        logger.info('***** Server.py getAlarmById is running *****')
        try:
            alarms = self.impl.getAlarmsByObjId(vmc_uuid.strip())
            if alarms is None or len(alarms) == 0:
                return None

            warpped_alarms = []
            for alarm in alarms:
                alarm2dict = {}
                for key in alarm.__dict__:
                    alarm2dict[key] = getattr(alarm, key)
                alarm2dict["_typename"] = alarm.__class__.__name__
                warpped_alarms.append(SOAPpy.Types.structType(alarm2dict))
            return SOAPpy.Types.arrayType(warpped_alarms)
        except Exception as e:
            logger.error(e.message)
            return None

    # 依据警告类型和名称获取警告列表
    def getAlarmsByObjIdAndName(self, vmc_uuid, ref_obj_name):
        logger.info('***** Server.py getAlarmsByObjIdAndName is running *****')
        try:
            alarms = self.impl.getAlarmsByObjIdAndName(vmc_uuid.strip(), ref_obj_name.strip())
            if alarms is None or len(alarms) == 0:
                return None

            warpped_alarms = []
            for alarm in alarms:
                alarm2dict = {}
                for key in alarm.__dict__:
                    alarm2dict[key] = getattr(alarm, key)
                alarm2dict["_typename"] = alarm.__class__.__name__
                warpped_alarms.append(SOAPpy.Types.structType(alarm2dict))
            return SOAPpy.Types.arrayType(warpped_alarms)
        except Exception as e:
            logger.error(e.message)
            return None

    # 获取所有存储列表
    def getAllStorages(self):
        logger.info('***** Server.py getAllStorages is running *****')
        try:
            storages = self.impl.getAllStorages()
            if storages is None or len(storages) == 0:
                return None

            warpped_storages = []
            for storage in storages:
                storage2dict = {}
                for key in storage.__dict__:
                    storage2dict[key] = getattr(storage, key)
                storage2dict["_typename"] = storage.__class__.__name__
                warpped_storages.append(SOAPpy.Types.structType(storage2dict))
            return SOAPpy.Types.arrayType(warpped_storages)
        except Exception as e:
            logger.error(e.message)
            return None

    def getStorageById(self, storage_uuid):
        logger.info('***** Server.py getStorageById is running *****')
        try:
            storage = self.impl.getStorageById(storage_uuid)
            if storage is None:
                return None

            storage2dict = {}
            for key in storage.__dict__:
                storage2dict[key] = getattr(storage, key)
            storage2dict["_typename"] = storage.__class__.__name__
            return SOAPpy.Types.structType(storage2dict)
        except Exception as e:
            logger.error(e.message)
            return None

    # 判断服务是否可连接
    def isConnected(self):
        return '1'

    # 获取虚拟机电源、网络连接状态
    def getVmiPowerState(self, vmi_uuid):
        logger.info('***** Server.py getVmiPowerState is running *****')
        try:
            power_state, ip = self.impl.getVmiPowerState(vmi_uuid)
            result = commands.getstatusoutput('ping -c 1 %s | grep min/avg/max/mdev' % ip)
            if result[0] == 0:
                vmi_net_state = '1'
            else:
                vmi_net_state = '2'

            vmi_power_state = '未知'
            if power_state == 'running':
                vmi_power_state = '1'
            elif power_state == 'stopped':
                vmi_power_state = '3'
            elif power_state == 'paused':
                vmi_power_state = '2'
            return '%s_%s' % (vmi_power_state, vmi_net_state)
        except Exception as e:
            logger.error('getVmiPowerState is error: %s' % e.message)
            return None

    # 获取iso存储路径
    def getIsoPath(self, storage_uuid):
        logger.info('***** Server.py getIsoPath is running *****')
        try:
            iso_path = self.impl.getIsoPath(storage_uuid)
            return iso_path.strip()
        except Exception as e:
            logger.error('getIsoPath is error: %s' % e.message)
            return None

    # 获取iso列表
    def getIsoByStorageId(self, storage_uuid):
        logger.info('***** Server.py getIsoByStorageId is running *****')
        try:
            isos = self.impl.getIsoList(storage_uuid)
            if isos is None:
                return None
            return ','.join(isos)
        except Exception as e:
            logger.error('getIsoByStorageId is error: %s' % e.message)
            return None

    # 获取所有ip池列表
    def getAllIpPools(self):
        logger.info('***** Server.py getAllIpPools is running *****')
        try:
            vlans = self.impl.getAllIpPools()
            if vlans is None:
                return None

            warpped_vlans = []
            for vlan in vlans:
                vlan2dict = {}
                for key in vlan.__dict__:
                    vlan2dict[key] = getattr(vlan, key)
                vlan2dict["_typename"] = vlan.__class__.__name__
                warpped_vlans.append(SOAPpy.Types.structType(vlan2dict))
            return SOAPpy.Types.arrayType(warpped_vlans)
        except Exception as e:
            logger.error('getAllVlans is error: %s' % e.message)
            return None

    # 验证主机网络状态
    def checkVmcPower(self, address):
        logger.info('***** Server.py checkVmcPower is running *****')
        try:
            result = commands.getstatusoutput('ping -c 1 %s | grep min/avg/max/mdev' % address)
            if result[0] == 0:
                vmc_power = '2'
            else:
                vmc_power = '1'
            return vmc_power
        except Exception as e:
            logger.error('checkVmcPower is error: %s' % e.message)
            return 'unknown'

    @nullReturnWrapper
    def update_ha_info(self, master_ip, cluster, info_dict):
        return self.impl.update_ha_info(master_ip, cluster, info_dict)

    def getUuidById(self, id, type):
        uuid = self.impl.getUuidById(id, type)
        return uuid
