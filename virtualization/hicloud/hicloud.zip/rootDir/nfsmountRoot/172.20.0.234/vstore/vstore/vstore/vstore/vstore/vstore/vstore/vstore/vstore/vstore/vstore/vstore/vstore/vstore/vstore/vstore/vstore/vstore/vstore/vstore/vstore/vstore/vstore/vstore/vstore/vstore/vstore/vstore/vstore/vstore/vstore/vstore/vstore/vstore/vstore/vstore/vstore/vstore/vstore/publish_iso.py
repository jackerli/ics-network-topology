#!/usr/bin/env python
# -*- coding: utf-8 -*-

# format:
#     python publish_iso.py iso_path iso_type iso_version    
#     NOTE: iso_typs is windows or linux

# samples:
#     python publish_iso.py /home/win7.iso windows win7
#     python publish_iso.py /home/ubuntu.iso linux ubuntu14


import os
import signal
import sys

from hicloud.core import Config, project_path, Logging

config_vstore_path = project_path("/etc/hicloud/vstore.yaml")
config_vstore = Config.load(config_vstore_path)

logger = Logging.get_logger(__name__)


def exe_command(command):
    try:
        pipe = os.popen(command, "r")
        result = pipe.readlines()
        return result
    except Exception as err:
        return None
    finally:
        pipe.close()


def do_publish_iso(argv):
    send_url = config_vstore['iso_url']
    logger.info("send_url: %s" % send_url)
    iso_path = argv[1]
    # iso_name = argv[2]
    iso_name = iso_path.split('/')[-1].strip()
    iso_os_type = argv[2]
    iso_os_version = argv[3]
    # send_url = "10.1.1.49:12345/api/add/iso/"
    cmd = "curl -X POST -d \"" + "name=%s&type=%s&version=%s&" % (iso_name, iso_os_type, iso_os_version)
    cmd += "\" -H \"Accept: text/xml\" " + send_url
    logger.info("cmd: %s" % cmd)
    os.system(cmd)

    send_cmd = "cp %s %s " % (iso_path, config_vstore['iso_path'])
    logger.info("send_cmd: %s" % send_cmd)
    os.system(send_cmd)


def main():
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)

    do_publish_iso(sys.argv)

    logger.info('publish iso is finished')


# This is the entry when running as a standalone module
if __name__ == "__main__":
    main()
