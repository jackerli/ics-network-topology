class tryServer:
    def __init__(self):
        a = 2
    def func1(self,a,b,c):
        return a+b+c

