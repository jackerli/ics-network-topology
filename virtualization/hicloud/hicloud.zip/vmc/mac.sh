ifconfig eth0 down
ifconfig eth0 hw ether 0c:c4:7a:b3:02:4d
ifconfig eth0 up
